sum = lambda first_num, second_num : first_num + second_num

print(sum(10, 20))


def display(first_num, second_num):
    print(f'The sum of 2 numbers: {first_num + second_num}')

